### TODOS

- manual check (i.e. send email to courtbooker824@gmail.com to check availabilities)
- check GET and POST requests on Avalon site, maybe we can remove Web scraping and just submit API requests
- debug web hook
